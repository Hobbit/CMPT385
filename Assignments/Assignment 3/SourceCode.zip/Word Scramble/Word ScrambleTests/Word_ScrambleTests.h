//
//  Word_ScrambleTests.h
//  Word ScrambleTests
//
//  Created by Chris Hobbs on 2012-09-08.
//  Copyright (c) 2012 Team Red Panda. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Word_ScrambleTests : SenTestCase

@end
