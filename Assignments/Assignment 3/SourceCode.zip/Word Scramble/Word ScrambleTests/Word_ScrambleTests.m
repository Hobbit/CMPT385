//
//  Word_ScrambleTests.m
//  Word ScrambleTests
//
//  Created by Chris Hobbs on 2012-09-08.
//  Copyright (c) 2012 Team Red Panda. All rights reserved.
//

#import "Word_ScrambleTests.h"

@implementation Word_ScrambleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Word ScrambleTests");
}

@end
