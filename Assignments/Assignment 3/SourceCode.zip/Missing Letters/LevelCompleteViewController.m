//
//  LevelCompleteViewController.m
//  Missing Letters
//
//  Created by Chris on 2012-10-25.
//  Copyright (c) 2012 Team Red Panda. All rights reserved.
//
//  Code Standard:
//  http://developer.apple.com/library/ios/#documentation/Cocoa/Conceptual/CodingGuidelines/CodingGuidelines.html
//

#import "LevelCompleteViewController.h"

@interface LevelCompleteViewController ()

@end

@implementation LevelCompleteViewController

//Nothing to go here yet, place holder for future versions

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
