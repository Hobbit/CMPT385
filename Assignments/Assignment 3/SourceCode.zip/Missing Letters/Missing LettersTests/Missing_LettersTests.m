//
//  Missing_LettersTests.m
//  Missing LettersTests
//
//  Created by Chris Hobbs on 2012-10-14.
//  Copyright (c) 2012 Team Red Panda. All rights reserved.
//

#import "Missing_LettersTests.h"

@implementation Missing_LettersTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Missing LettersTests");
}

@end
