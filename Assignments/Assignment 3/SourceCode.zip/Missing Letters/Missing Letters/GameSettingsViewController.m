//
//  SettingsViewController.m
//  Missing Letters
//
//  Created by Chris Hobbs on 2012-10-26.
//  Copyright (c) 2012 Team Red Panda. All rights reserved.
//
//  Code Standard:
//  http://developer.apple.com/library/ios/#documentation/Cocoa/Conceptual/CodingGuidelines/CodingGuidelines.html
//

#import "GameSettingsViewController.h"

@interface GameSettingsViewController ()

@end

@implementation GameSettingsViewController

//Nothing to go here yet, place holder for future versions

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [super viewDidUnload];
}
@end
